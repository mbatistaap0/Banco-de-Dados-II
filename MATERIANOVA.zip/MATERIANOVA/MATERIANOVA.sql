-- Projeto TCQL -- 
CREATE DATABASE ProjetoTSQLTB;

-- utilizando a base de dados --
USE ProjetoTSQLTB;

-- Criando a tabela Clientes --
CREATE TABLE Clientes (
Nome varchar(100),
Endereço varchar(100),
Telefone varchar(25),
Email varchar(100));

/*
Alter table serve para realizar alterações nas tabelas.
	--> ADD - Adicionar campos nas tabelas.
    --> DROP - Remover campos nas tabelas.
*/

Alter table Clientes ADD DataNascimento DATETIME;
Alter table Clientes ADD Codigo INT auto_increment PRIMARY KEY;
/* INT IDENTITY (1,1) PRIMARY KEY */

/* 
Inserindo registros na tabela Clientes utilizando o comando INSERT / INTO
*/

insert into Clientes (
Nome, 
Endereço,
Telefone,
Email,
DataNascimento)
values
('João da Silva', 'Rua das Pedras, 132, São José dos Campos, SP', '(12) 3925-1520', 'joao@gmail.com', '1987-12-18'),
('Agatha Hugo', 'Rua das Margaridas, 65, São José do Rio Preto, MT', '(13) 91420-0387', 'agathahug@hotmail.com', '1999-10-02'),
('Humberto Souza', 'Recanto Cidade Verde, 98, Rio de Janeiro, RJ', '(12) 87997-8765', 'humberts@gmail.com', '2002-05-20'),
('Gabriel Thiago', 'Avenida Fagulhas Cinzas, 55, Maranhão, AM', '(14) 52140-6541', 'gabris@gmail.com', '2000-01-13'),
('Claudio José', 'Recanto Cidade Verde, 213, Salvador, BA', '(12) 63214-2540', 'claudin@hotmail.com', '1985-08-14'),
('Kiara Batella', 'Avenida Agulhas Negras, 62, Gramado, RS', '(13) 65632-6528', 'kikis@gmail.com', '2001-04-10'),
('Joaquim Ramos', 'Rua Marina Campos, 170, São Paulo, SP', '(17) 95142-3652', 'joaqramos@gmail.com', '2003-02-15'),
('Jabari Cesar', 'Rua Roberto Sales, 86, Aracati, DF', '(16) 35247-5474', 'jabars@gmail.com', '1999-09-25'),
('Logan Nicolaj', 'Pico do Dente de Leão, 160, Ouro Preto, MG', '(14) 52103-6574', 'logins@gmail.com', '1991-10-06'),
('Stephanie Smith de Ha Ha', 'Rua Pimento José Silva, 12, Cuiabá, MT', '(13) 65478-3214', 'stephs@gmail.com', '2002-11-07');

/*-----------------------------------------------------------------------------------------------------------------------------------*/

/*
TRABALHANDO COM O COMANDO SELECT

O comando SELECT retorna as consultas registradas dentro do banco de dados. Como exemplo, vamos consultar TODOS os registros da tabela Clientes utilizando o (*)
para retornar todos os campos da tabela Clientes.
*/
SELECT * FROM Clientes;

/*------------------------------------------------------------------------------------------------------------------------------------*/
 
/*
FUNÇÃO GETDATE / CURDATE

A função GETDATE() para o SQLServer / CURDATE() para o Workbench, usada para obter a data atual do sistema.
Você pode utilizar esse comando dentro de um contexto de consulta.
*/

SELECT
    Codigo,
    Nome,
    CURDATE() as "Data Atual" 
FROM 
   Clientes;
   
/*
Podemos adicionar ou subtrair valores diretamente da função usando operadores aritméticos.
Exemplo:
*/
SELECT
    Codigo,
    Nome, 
    Email,
    CURDATE() - 5 AS "Data Atual - Cinco Dias", -- GETDATE() - 5 as [Data Atual - Cinco Dias],
    CURDATE() AS "Data Atual", -- GETDATE() - as [Data Atual],
    CURDATE() + 5 AS "Data Atual + Cinco Dias" -- GETDATE() + 5 as [Data Atual + Cinco Dias]
FROM
  Clientes;
  
  /* 
  FILTRO DE REGISTRO COM O COMANDO WHERE
  Podemos filtrar os registros que desejamos visualizar com base em determinados critérios que atendem à necessidade
  de negócio utilizando, comparando os campos com determinados condições estabelecidas, usando operadores de comparação 
  (>, <, >=, <=).
  Exemplo:
  */
SELECT
	Codigo,
	Nome, 
	Endereço,
	Telefone,
	Email,
	DataNascimento
FROM
    Clientes
WHERE
    Codigo >= 6;
/*----------------------------------------------------------------------------------------------------------------------------------*/

/* Operador AND

Podemos utilizar o operador AND  para limitar ou buscar pesquisas entre um registro e outro.
Exemplo:
Para podermos realizar uma seleção de clientes que possui código maior que 2 e a DataNascimento maior do que
10/11/1987 devemos utilizar:
*/

SELECT
    Codigo,
    Endereço,
    Telefone, 
    Email,
    DataNascimento
FROM
    Clientes
WHERE
    Codigo > 2 AND DataNascimento > '19871110';
    
-- Queremos nesse código selecionar os registros que tem como código maior que 2 e DataNascimento maior do que 10/11/1987 --

/* 
Operador OR 

Assim como o AND, o operador OR serve para retornar uma lista de registros que satisfaz uma ou outra condição.
*/

SELECT 
   Codigo,
   Nome, 
   Endereço,
   Email,
   DataNascimento
FROM
   Clientes
WHERE
   Codigo > 7 OR DataNascimento > '19890708';

-- Filtro de registro que lista o Código maior que 7 ou DataNascimento > 08/07/1989
/*---------------------------------------------------------------------------------------*/

/* 
Operador LIKE
Você pode utilizar o operador LIKE em seus códigos para realizar pesquisas aproximadas em campos de caracteres.
Exemplo:
Para consultar todos os registros da tabela com o primeiro caractere do campo NOME igual a "M" iremos utilizar:
*/
SELECT
    Codigo,
    Nome, 
    Endereço,
    Email,
    DataNascimento
FROM
    Clientes
WHERE
    Nome LIKE 'M&';
   
/*
O caractere "&" permite realizar a consulta aproximada. Podemos usar % para pesquisar o começo mas também o final de uma string.
*/
SELECT * FROM Clientes  WHERE Nome LIKE '%o';

/*------------------------------------------------------------------------------------------------------------------------------*/

/*
Comando TOP para SSMS / LIMIT (no Workbench)
O comando TOP permite limitar o número de registros que serão mostrados pela instrução SELECT, a qual recebe como argumento único o número
de registros a serem mostradoos pela query(instrução).
*/

SELECT
    Codigo
    Nome, 
    Telefone,
    DataNascimento
FROM
    Clientes
LIMIT 5;
    
/*
No SSMS seria:
SELECT
    TOP 5
    Codigo,
    Nome,
    Telefone,
    DataNascimento
FROM 
    Clientes
*/

-- ------------------------------------------------------------------------------------------------------------------------------*/

/*
Ordenação de registros com ORDER BY

Para dispor os registros em uma determinada ordem, utilizamos o comando ORDER BY.
Ele espera apenas uma indicação das colunas em que você deseja ordenar a seleção desejada.
Exemplo:
Para colocar os registros da tabela clientes por ordem alfabética do campo Nome, utilizamos:
*/

SELECT
    Codigo, 
    Nome, 
    Endereço,
    Telefone,
    Email,
    DataNascimento
FROM
    Clientes
ORDER BY
    Nome;
-- ------------------------------------------------------------------------------------------------------------
/*
Atualização dos registros com o comando UPDATE

O comando UPDATE permite atualizar registros em tabelas de banco de dados, alterando o valor de uma ou mais colunas.
*/

UPDATE
    Clientes
SET
    Nome = "Karina Bach",
    Endereço = "Avenida Brasil, 251, Rio de Janeiro, RJ",
    Telefone = "(21) 2333-9876",
    DataNascimento = "20000724"
WHERE
    Codigo = 4;

-- Para verificar se alterações foram modificadas --
SELECT * FROM Clientes;
-- ---------------------------------------------------------------------------------------------------------- 
/*
Função ISNULL / IFNULL (para o Workbench)

Esta função é utilizada para tratar campos com valores "nulos", seja em consultas ou em trechos de código SQL.
Vamos adicionar o campo CEP na tabela Clientes para verificar o seu funcionamento.
*/

Alter table Clientes ADD CEP varchar(9);

/*
Ao executar o comando SELECT * Clientes, podemos verificar que a coluna CEP está com o identificador "NULL" em todos os registros
da tabela, pois não realizaremos nenhum UPDATE na coluna recém-criada. Para fins de relatório e de apresentação de dados mais formais, é possível 
tocar o indicador "NULL" por outro mais adequado.
*/
SELECT
	Codigo,
      Nome, 
      Endereço,
      Telefone, 
      Email,
      DataNascimento,
      IFNULL (CEP, 'SEM CEP') as CEP -- Para o Workbench
FROM
    Clientes;
-- ------------------------------------------------------------------------------------------------------
/*
Exclusão de registros com o comando DELETE

Para excluir um registro que foi inserido em uma tabela do SQL Server, devemos utilizar o comando DELECT, que assim
como o comando INSERT e UPDATE, pode se utilizar a claúsula WHERE para filtrar os dados a serem excluídos.
*/

DELETE FROM Clientes WHERE Codigo = 6;
-- ---------------------------------------------------------------------------------------------------------------
/*
Comando TRUNCATE TABLE
Para realizar a EXCLUSÃO de TODOS os registros de uma tabela, utilizamos o comando TRUNCATE TABLE. Para excluir
TODOS os registros de uma tabela, podemos utilizar esse comando. 
*/
TRUNCATE TABLE Clientes;
-- ---------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------
/*
LISTA DE EXERCÍCIO 1 - Estudo de Caso da Biblioteca
LISTA DE EXERCÍCIO 2 - Universidade
LISTA DE EXERCÍCIO 3 - Prova
*/
-- ---------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------------------------------------------------------------------------
/* 2° BIMESTRE
Criando a tabela Produtos
*/

create table Produtos (
   Codigo_Produtos int auto_increment primary key,
   Descrição varchar (150),
   ValorVenda numeric (18,2),
   Ativo BIT default (1));
   
 /* 
 Para atender ao requisito de valor padrão no campo "Ativo", foi utilizada a instrução DEFAULT, em que foi informado ao valor 1. 
 A propriedade IDENTITY já utilizamos anteriormentee o campo ValorVenda está como NUMERIC que aceita dois argumentos, onde a primeira 
 parte é o número de casas antes da vírgula e a segunda parte é o número de casas decimais depois da vírgula
 */
 -- ---------------------------------------------------------------------------------------------------------------
  
create table Vendas (
   Codigo_Vendas int auto_increment primary key,
   Cliente int references Clientes(Codigo),
   Produto int,
   DataVenda DATETIME DEFAULT CURDATE(),
   Quantidade int,
   ValorVenda numeric(18,2));
   
/*
A instrução REFERENCES recebe como argumento a tabela e o campo em que a respectiva chave primária foi definida. Desta forma, todos os 
valores atribuídos aquela coluna devem ter uma correspondência em outra tabela.
O campo DataVenda foi definida como DATETIME e com a instrução DEFAULT atribuindo o valor da função GETDATE() em que retorna a data atual do dia. 

*/ 
-- -----------------------------------------------------------------------------------------------------------------

/*
Vamos criar uma outra maneira de fazer o relacionamento da tabela VENDAS com tabela PRODUTOS.
*/

ALTER TABLE Vendas ADD CONSTRAINT fkProdutos
FOREIGN KEY (Produto) REFERENCES Produtos (Codigo);

/*
Sempre que criamos uma chave estrangeira, o SQL Server cria uma CONSTRAINT  para assegurar a integridade da chave estrangeira> 
Quando criamos a chave estrangeira de Clientes na criação da tabela usando apenas a instrução REFERENCES, a criação CONSTRAINT foi
implícita cm um nome gerado automaticamente.
Quando criamos o comando ALTER TABLE podemos atribuir um novo explícito a essa CONSTRAINT.
*/ 
-- -----------------------------------------------------------------------------------------------------------------
-- INSENÇÃO DE REGISTROS NAS TABELAS PRODUTOS E VENDAS 

INSERT INTO Produtos (Descrição, ValorVenda, Ativo) 
VALUES 
('3DS MAX 2020-MODELAGEM, RENDER, EFEITOS', 161.95, 1),
('Projetor De Cinema', 154.80 , 1),
('Smart TV Philco', 4.500 , 1),
('Smartphone Samsung', 2.400, 1),
('O Jantar Secreto', 24.90 ,1),
('Iphone 11', 4.000, 1),
('Quem é você, Alasca?', 34.99, 1),
('As Vantagens de ser Invisível', 22.30 , 1),
('Suicidas', 35.90, 1),
('Flores para Algernon', 44.70, 1);

SELECT * FROM Produtos;

INSERT INTO Vendas (Cliente, Produto, DataVenda, Quantidade, ValorVenda)
VALUES
(2, 7, 20210907, 2, 155.90),
(4, 5, 20221019, 4, 75.80),
(3, 3, 20200602, 1, 54.00),
(7, 2, 20220523, 7, 40.00),
(9, 8, 20200301, 8, 78.90),
(10, 9, 20221205, 10, 30.20),
(1, 4, 20230118, 5, 14.80),
(5, 1, 20220815, 6, 9.89),
(6, 10, 20211105, 9, 76.80),
(8, 6, 20230317, 3, 10.89);

/*
CRIANDO RELAÇÃO ENTRE AS TABELAS 
1 - Clicar na aba de Banco de Dados (Databases) ao lado esquerdo;
2 - Abrir a base de dados desejado;
3 - Clicar com o botão direito do mouse na aba Diagrama de Banco de Dados (Database Diagrams);
4 - Novo Diagrama de Banco de Dados (New Database Diagram)
5 - Escolhe todas as tabelas e insira;
6 - Close 
*/

-- -----------------------------------------------------------------------------------------------------------------
/*
TEORIA DOS COMJUNTOS E OS JOINS DE BANCO DE DADOS 

O JOIN é uma cláusula da linguagem SQL que permite criar consultas combinando resultados de uma ou duas tabelas por meio de valores
comuns entre uma ou várias colunas de cada tabela. Quando se fala em uma tabela, a referência é feita a casos específicos chamamos de
JOIN de uma tabela com ela mesmo.
*/

-- -----------------------------------------------------------------------------------------------------------------
 /* 
 COMANDO INNER JOIN
 
 O INNER JOIN consulta os registros de duas tabelas, verificando todos os registros de cada uma e selecionando os que tem valores em comum,
 com base no critério estabelecendo no JOIN. 
 Neste banco de dados criamos três tabelas, sendo Clientes, Produtos e Vendas. Estabelecendo dois relacionamentos entre Clientes e Vendas, e entre as tabelas 
 Produtos e Vendas, desta forma não é possível inserir vendas com Clientes que não existem, mas é possível que existem Clientes que não realizam Vendas. 
 Para listar o Nome de cada Cliente e a DataVenda também de cada Cliente, podemos usar o comando INNER JOIN.
 
 Exemplo:
 */
 
SELECT
	Nome,
	DataVenda
FROM
	Clientes C
INNER JOIN Vendas V ON (C. Codigo = V. Cliente);

/*
O INNER JOIN é considerado o tipo de JOIN padrão. Podemos executar o mesmo comando anterior co outra sintaxe 
eliminando o INNER JOIN e obteremos o mesmo resultado.

SELECT 
    Nome,
    DataVenda
FROM 
    Clientes C
JOIN Vendas V ON (C.Codigo = V.Cliente)
*/

-- Com o INNER JOIN estamos trazendo a interação dos registros da tabela Clientes(ou conjunto A) e da tabela Vendas (conjunto B). --
-- -----------------------------------------------------------------------------------------------------------------
 
 /*
 COMANDO LEFT JOIN
 
 O comando LEFT JOIN, entre duas tabelas hipotéticas A e B, vai trazer todos os registros da tabela A independente 
 do critério estabelecido no JOIN. Ou seja, se a tabela A contém 100 registros e nenhum deles tem um correspondente na outra,
 baseado no critério de comparação, ainda assim vai trazer 100 registros, porém onde a correspondência existir, os dados correspondentes
 serão resgatados.
 */
 
SELECT
    Nome,
    DataVenda
FROM 
    Clientes C
LEFT JOIN Vendas V ON (C.Codigo = V.Cliente);
-- -----------------------------------------------------------------------------------------------------------------

/*
COMANDO RIGHT JOIN

O comando RIGHT JOIN produz um resultado semelhante ao LEFT JOIN, porém com a inversão da comparação.
Exemplo: em nosso banco de dados criamos uma tabela chamada PRODUTOS que relaciona com a tabela VENDAS.
Podemos listar a descrição de todos os produtos e a data da venda de cada um deles junto com os produtos que
não realizaram vendas através de uma query.
*/

SELECT
    Descrição,
    DataVenda
FROM
    Vendas V
RIGHT JOIN Produtos P ON (P.Codigo = V.Produto);
-- ---------------------------------------------------------------------------------------------------------------

/*
COMANDO CASE

O comando CASE avalia uma lista de condições verificadas em um ou mais campos e retorna apenas um (1) de vários
(n) resultados possíveis.
SINTAXE:

SELECT
    CASE 
       WHEN <EXPRESSÃO LÓGICA1>
           THEN <RESULTADO DA EXPRESSÃO 1>
        WHEN <EXPRESSÃO LÓGICA 2>
           THEN <RESULTADO DA EXPRESSÃO 2>
           
	ELSE 
        <RESULTADO FORA DAS CONDIÇÕES LISTADAS>
	END
FROM
   <TABELA>
*/

SELECT
    Codigo,
    Descrição,
    CASE
        WHEN ValorVenda BETWEEN 0 AND 100
            THEN 'Bronze'
		WHEN ValorVenda BETWEEN 101 AND 200
            THEN 'Prata'
		WHEN ValorVenda BETWEEN 201 AND 300
            THEN 'Ouro'
		WHEN ValorVenda > 300
            THEN 'Platina'
	ELSE
        'Não classificado'
	END AS Tipo_do_Produto
FROM
    Produtos;
    
-- ---------------------------------------------------------------------------------------------------------------
/*
 FUNCÕES DE AGREGAÇÃO 
  
As funções de agregação realizam cálculos com um conjunto de valores determinados pela condição estabelecida em
claúsula GROUP BY, retornando um valor único para aquele conjunto. Para que você possa melhorar a utilização das
funções de agregação, vamos utilizar diversos exemplos.

Uso do comando COUNT 
A função COUNT pode ser usada para contar o número de registros estabelecidos em uma condição GROUP BY.
Exemplo:
Para contar o número de compras realizadas por cada cliente em um determinado dia, podemos usar o seguinte
comando:
*/ 
SELECT
    Nome,
    DataVenda,
    COUNT(*) as TotalVendas
FROM Clientes 
INNER JOIN Vendas V ON (V.Cliente = C.Codigo)
GROUP BY
    Nome, DataVenda;
    
/*
SELECT COUNT (Nome, DataVenda) as TotalVendas
FROM Clientes C
GROUP BY
    Nome, DataVenda
*/
-- ---------------------------------------------------------------------------------------------------------------
/*
Soma dos valores com SUM

A função SUM soma os valores numericos em um conjunto de valores estabelecidos pelo GROUP BY.
A tabela VENDAS tem um campo determinado "ValorVenda", que armazena o valor pelo qual o produto foi vendido.
Podemos executar o seguinte script para conhecer o valor vendido para cada cliente.
*/
SELECT
    Nome,
    DataVenda,
    SUM(ValorVenda) as TotalVendas
FROM
    Clientes C
INNER JOIN Vendas V ON (V.Cliente = C.Codigo)
ORDER BY Nome, DataVenda;

        -- OUTRA FORMA--

SELECT
    Nome,
    P.Descrição,
    V.ValorVenda as TotalVendas,
    P.ValorVenda as TotalVendasProduto,
    (V.ValorVenda - P.ValorVenda) as Descrição
FROM
    Clientes C
INNER JOIN Vendas V ON (V.Cliente = C.Codigo)
INNER JOIN Produtos P ON (P.Produto = P.Codigo)
ORDER BY Nome;

/*
A query anterior retorna uma listagem de cada um dos clientes e os produtos comprados por eles, assim como o 
valor venda, o valor venda cadastrado na tabela produtos (coluna "ValorVendaProduto") e o cálculo do desconto
ofertado ao cliente, que é a diferença entre o valor de venda e o valor de venda cadastrado na tabela produtos.

Para calcularmos o total de vendas e o total de desconto para cada cliente, podemos executar\;
*/

SELECT
    Nome,
    SUM(V.ValorVenda) as TotalVendas,
    SUM(quantidade * P.ValorVenda) as ValorVendaProduto,
    SUM(quantidade * V.ValorVenda) - SUM(quantidade* P.ValorVendas) as Desconto
FROM
    Clientes C
INNER JOIN Vendas V ON (V.Cliente = C.Codigo)
INNER JOIN Produtos P ON (V.Produto = P.Codigo)
GROUP BY Nome
ORDER BY Nome;
    
-- ---------------------------------------------------------------------------------------------------------------
/*
Comando AVG
O comando AVG tira a média aritmética do ValorVenda da tabela Vendas utilizamos:
*/
SELECT
   AVG (ValorVenda) as MediaValorVenda
FROM
    Vendas;
-- ---------------------------------------------------------------------------------------------------------------
/*
Outra função de agregação é a instrução MIN e MAX, onde:
    -> MIN - Valor MÍNIMO de um conjunto de valores.
    -> MAX - Valor MÁXIMO de um conjunto de valores.
*/

-- Utilização do MIN --
SELECT 
    Nome,
    MIN (ValorVenda) as MenorVenda
FROM
    Clientes C
INNER JOIN Vendas V ON (C.Codigo = V.Codigo)
GROUP BY C.Nome;

-- Utilização do MAX --
SELECT 
    Nome,
    MAX (ValorVenda) as MaiorVenda
FROM
    Clientes C
INNER JOIN Vendas V ON (C.Codigo = V.Codigo)
GROUP BY C.Nome;

-- ---------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------------------------------------------------------------------------
-- ---------------------------------------------------------------------------------------------------------------

/*
CRIAÇÃO DAS VIEWS
Uma VIEW é uma tabela criada "virtualmente", através de uma query, que define seu conteúdo e metadados. 
A View tem uma série de propósitos, como por exemplo, fazer com que todos os desenvolvedores utilize a mesma
regra de negócio ao acessar um SET de dados ou, por questões de segurança, limitar o acesso aos objetos propriamente
dits para determinados usuários, delegando a eles acesso apenas as Views.

A sintaxe para a criação da VIEW é bastante simples. Basta utilizar o comando CREATE VIEW informando como argumento o 
nome da VIEW a ser criada, o prefixo AS e a query definirá a consulta a ser realizada.

EXEMPLO: Para criar uma VIEW listando apenas os clientes ativos, podemos utilizar:
*/

CREATE VIEW vwClientesAtivos
	AS
		SELECT
			Codigo,
            Descricao,
            ValorVenda,
            Ativo
FROM
	Produtos
WHERE
	Ativo = 1;

-- Para acessar a VIEW criada utilizamos:

SELECT Codigo, Descricao, ValorVenda, Ativo
	FROM vwClientesAtivos;
    
-- ---------------------------------------------------------------------------------------------------------------
/* 
CRIAÇÃO DAS TRIGGERS

Trigger, do inglês, significa gatilho. No contexto de banco de dados, triggers são procedimentos armazenados, disparados
por eventos de atualização, exclusão ou inserção em tabelas de SGBD.

Para entender melhor como aplicar trigger em nosso exemplo, vamos acompanhar o enunciado.

Criar uma tabela denominada ProdutoHistorico, que deve armazenar todas as alterações realizadas na tabela Produtos.

Primeiramente vamos criar a tabela ProdutoHistorico, que deve ter a mesma estrutura na tabela Produtos, com um campo
adicional denominado DataAlteração que vai armazenar a data da operação e um campo TipoAlteração que vai armazenar um string.
Na atualização é preciso diferenciar os valores como estava, antes do UPDATE e como funciona depois do UPDATE. 
Vamos observar:
*/

CREATE TABLE dbo.ProdutoHistorico (
	Cod_ProdHistorico INT NOT NULL,
	Desc_ProdHist varchar(150) NULL,
    ValorVenda_PH NUMERIC(18, 2) NULL,
    Ativo_PH BIT NULL,
    DataAlteracao_PH DATETIME,
    TipoAlteracao_PH varchar(100));
    
/*
Agora, vamos criar a trigger propriamente dita para armazenar atualizações. 
*/

CREATE TRIGGER UpdateProdutos ON Produtos
	FOR UPDATE AS
    BEGIN
		SET NOCOUNT ON
        
        INSERT ProdutoHistorico(Cod_ProdHistorico, Desc_ProdHist, ValorVenda_PH, Ativo_PH, DataAlteracao_PH, TipoAlteracao_PH)
        SELECT Cod_ProdHistorico, Desc_ProdHist, ValorVenda_PH, Ativo_PH, DataAlteracao_PH, TipoAlteracao_PH, CURDATE(), 'Udate OLD' FROM Deleted

		INSERT dbo.ProdutoHistorico(Cod_ProdHistorico, Desc_ProdHist, ValorVenda_PH, Ativo_PH, DataAlteracao_PH, TipoAlteracao_PH)
        SELECT Cod_ProdHistorico, Desc_ProdHist, ValorVenda_PH, Ativo_PH, DataAlteracao_PH, TipoAlteracao_PH, CURDATE(), 'Udate NEW' FROM Inserted
END;

/*
Observe que a Trigger deve referenciar sempre uma tabela, portanto a declaração de criação do procedimento:
	CREATE Trigger UpdateProdutos ON Produtos.
O argumento FOR UPDATE determina que a Trigger captura apenas os eventos de atualização de dados. Os eventos
de inserção e exclusão não serão capturados pela Trigger. 

No corpo da Trigger, no contexto UPDATE, o desenvolvedor tem acesso a duas tabelas virtuais, sendo INSERTED e 
DELETED.
	
		--> INSERTED - é um SET de dados com os novos valores.
        --> DELETED - é um SET de dados com os valores antigos.
        
Essas tabelas virtuais estão acessíveis apenas no escopo da procedure. No código de exemplo adicionado
anteriormente, foram utilizados essas tabelas para realizar dois inserts na tabela que criamos anteriormente
ProdutoHistorico

Agora, vamos testar o funcionamento dessa trigger. Vamos executar o UPDATE apresentado a seguir:
*/

UPDATE Produtos
	SET Descricao = 'T-SQL com Microsoft SQL Server 2012 Express'
    WHERE Codigo = 4;
    
UPDATE Produtos
	SET ValorVenda = 104.90
    WHERE Codigo = 4;
    
/*
Agora, vamos executar essa consulta na tabela ProdutoHistorico:
*/
 
SELECT * FROM ProdutoHistorico

/*
Algumas opções de eventos que pode ser aplicado nas TRIGGERS:
	--> BEFORE INSERT (Antes de Inserir)
    --> AFTER INSERT (Depois de inserir)
    --> BEFORE UPDATE (Antes de atualizar)
    --> AFTER UPDATE (Depois de atualizar)
    --> BEFORE DELETE (Antes de apagar)
    --> AFTER DELETE (Depois de apagar)
    
*/




