CREATE DATABASE Livraria;
USE Livraria;

-- 1 ----------------------------------------------------------------
CREATE TABLE Autores (
Autor_ID int auto_increment primary key,
Nome_Autor varchar (50));

CREATE TABLE Livros (
Livro_ID int auto_increment primary key,
Título varchar (40),
Autor_ID int references Autores (Autor_ID),
Quantidade int);

CREATE TABLE Emprestimos (
Emprestimos_ID int auto_increment primary key,
Livro_ID int references Livros (Livro_ID),
Data_Empréstimo datetime,
Data_Devolução datetime);

-- 2 ----------------------------------------------------------------
INSERT INTO Autores (
Nome_Autor)
VALUES
('C.J Taylor'),
('Raphael Montes'),
('Clarice Lispector');

INSERT INTO Livros (
Título,
Autor_ID,
Quantidade)
VALUES
('O Jantar Secreto', 2 , 4),
('Suicidas', 2, 3),
('A Hora da Estrela', 3, 6),
('O que aconteceu com Annie', 1, 1),
('Água Viva', 3, 2);


INSERT INTO Emprestimos (
Livro_ID,
Data_Empréstimo,
Data_Devolução)
VALUES
(4, '20210830', '20210920'),
(3, '20200225', '20200514'),
(1, '20220306', '20220923'),
(2, '20190710', '20200120');

-- 3 ----------------------------------------------------------------
SELECT
	Nome_Autor,
	Count(Quantidade) as QtdAutor
FROM
	Livros L 
INNER JOIN Autores A ON (A. Autor_ID = L. Autor_ID)
GROUP BY
	Nome_Autor;
    
-- 4 ---------------------------------------------------------------- 
SELECT
	SUM(Quantidade) as TotalLivros
FROM
	Livros;
    
-- 5 ----------------------------------------------------------------
SELECT
	MIN(Quantidade) as MenorQuantidade
FROM
	Livros;
    
 -- 6 ----------------------------------------------------------------
SELECT 
	Título
FROM
	Livros
ORDER BY
	Título;
    
-- 7 ----------------------------------------------------------------
SELECT
	MAX(Quantidade) as MaiorQuantidade
FROM
	Livros;
    
-- 8 ----------------------------------------------------------------
    
SELECT
	Livro_ID as Livro_Emprestado,
    Data_Empréstimo
FROM 
	Emprestimos 
GROUP BY
	Data_Empréstimo
ORDER BY
	Data_Empréstimo

-- ----------------------------------------------------------------
-- ----------------------------------------------------------------
-- ----------------------------------------------------------------

-- Crie uma view para total de empréstimos por livro(count e 1 inner join)
-- Crie uma view para livros disponíveis(count e 1 inner join)
-- Crie uma view para empréstimos atrasados(1 inner join)
    

