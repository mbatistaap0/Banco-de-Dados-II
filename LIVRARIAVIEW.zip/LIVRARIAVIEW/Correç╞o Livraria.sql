create database Biblioteca;
use Biblioteca;

-- 1 --------------------------------------------------------------------------
create table Autores(
	Codigo_Autor int auto_increment primary key,
    Nome_Autor varchar(40));
create table Livros(
	Codigo_Livro int auto_increment primary key,
    Titulo_L varchar(20),
    ID_Autor int references Autores(Codigo_Autor),
    Quantidade_L int);
create table Emprestimos(
	Codigo_Empr int auto_increment primary key,
    ID_Livro int references Livros(Codigo_Livro),
    Data_Emprestimo date,
    Data_Devolucao date);

-- 2 --------------------------------------------------------------------------
insert into Autores(
	Nome_Autor)
values
("Keira Riff"),
("Oster Carvalhais"),
("Paul Carter");

insert into Livros(
	Titulo_L,
    Quantidade_L,
    ID_Autor)
values
("Conosco", 950, 2),
("E esse é o fim?", 320, 3),
("A verdade", 65, 1),
("DemisTério", 860, 1),
("Boas Novas", 350, 3);

insert into Emprestimos(
	ID_Livro,
    Data_Emprestimo,
    Data_Devolucao)
values
( 2,"20221226","20230129"),
( 3,"20231201","20240101"),
( 1,"20190924","20191024"),
( 4,"20231123","20231213");

select * from Autores;
select * from Livros;
select * from Emprestimos;

-- 3 --------------------------------------------------------------------------
select
	Nome_Autor,
	count(Quantidade_L) as Contagem
from Livros L
inner join Autores A on (A. Codigo_Autor = L. ID_Autor)
group by Nome_Autor;

-- 4 --------------------------------------------------------------------------
select
	Nome_Autor,
	sum(Quantidade_L) as Contagem
from Livros L
inner join Autores A on (A. Codigo_Autor = L. ID_Autor)
group by Nome_Autor;

-- 5 --------------------------------------------------------------------------
select
	Codigo_Livro,
    min(Quantidade_L) as MenorQnt_L
from Livros;

-- 6 --------------------------------------------------------------------------
select * from Livros
order by Titulo_L;

-- 7 --------------------------------------------------------------------------
select
	Codigo_Livro,
    max(Quantidade_L) as MaxQnt_L
from Livros;

-- 8 --------------------------------------------------------------------------
select 
	ID_Livro,
    Data_Emprestimo
from Emprestimos
group by Data_Emprestimo
order by Data_Emprestimo;

/*
9 - Crie uma view para total de empréstimos por livro(count e 1 inner join)
10 - Crie uma view para livros disponíveis(count e 1 inner join)
11 - Crie uma view para empréstimos atrasados(1 inner join)
*/

-- 9 --------------------------------------------------------------------------
create view vwTotalEmprestimos
	as
    select
    count(*) as TotalEmprestimos,
    Titulo_L
from Emprestimos E
inner join Livros L on (E.Codigo_Empr = L.Codigo_Livro)
group by Titulo_L;

select * from vwTotalEmprestimos;

-- 10 --------------------------------------------------------------------------
create view vwLivrosDisponiveis
	as
		select
        count(Codigo_Empr) as Disponiveis,
        Titulo_L
from Livros L
left join Emprestimos E on (L.Codigo_Livro = E.Codigo_Empr)
group by Titulo_L;

select * from vwLivrosDisponiveis;

-- 11 --------------------------------------------------------------------------
create view vwEmprestimosAtrasados
	as
		select
        E.Codigo_Empr,
        E.Data_Emprestimo,
        E.Data_Devolucao,
        L.Titulo_L
from Emprestimos E
inner join Livros L on (E.Codigo_Empr = L.Codigo_Livro)
where E.Data_Devolucao < Curdate();

select * from vwEmprestimosAtrasados;