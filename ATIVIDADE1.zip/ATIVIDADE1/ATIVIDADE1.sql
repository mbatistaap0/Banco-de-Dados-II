create database Biblioteca;
use Biblioteca;

create table Livros (
Cod_Livro int auto_increment primary key,
Título_Livro varchar (40),
Livro2 varchar (130),
Editora varchar (30),
Edição varchar (20),
Ano_Publicação varchar(4),
Autores varchar (50),
Assunto varchar (20),
Assunto_Livro2 varchar (20));

create table Alunos (
Cod_Matrícula int auto_increment primary key,
Nome_Aluno varchar (30),
Telefone varchar (15),
Celular varchar (17),
CPF varchar (14),
RG varchar (13),
Email_Aluno varchar (70));

create table Professores (
Cod_Professor int auto_increment primary key,
Nome_Professor varchar (40),
Endereço_Professor varchar (70),
Telefone_Professor varchar (15),
Celular_Professor varchar (17),
CPF_Professor varchar (14),
RG_Professor varchar (14),
Email_Professor varchar (75),
Titulação varchar (25));

create table Empréstimo (
Cod_Empréstimo int auto_increment primary key,
Cod_Aluno int references Alunos (Cod_Matrícula),
Cod_Professor int references Professores (Cod_Professor),
Cod_Livro int references Livros (Cod_Livros),
Data_Empréstimo datetime,
Data_Prevista datetime,
Nome_Livro1 int references Livros (Livro2),
Exemplar_Emprestado int references Livros (Cod_Livro));

create table Devolução (
Cod_Devolução int auto_increment primary key,
Cod_Aluno int references Alunos (Cod_Matrícula),
Cod_Professor int references Professores (Cod_Professor),
Cod_Livro int references Livros (Cod_Livros),
Situação_Empréstimo varchar(30),
Quant_Livros_devolver int);

insert into Livros (
Título_Livro,
Livro2,
Editora,
Edição,
Ano_Publicação,
Autores,
Assunto,
Assunto_Livro2)
values
('Senhor dos Anéis','Introdução à Física', 'Rocco', '2021', '1954', 'J.R.R. Tolkien ', 'Fantasia','Educação'),
('Matemática Básica','Essencialismo', 'Campus', '2015', '2012', 'Samuel Junior', 'Educação','Auto-Ajuda'),
('Pequeno Príncipe','As 48 Leis do Poder', 'intrinseca', '2017', '2015', 'Antoine de Saint-Exupéry', 'Ficção','Auto-Ajuda'),
('Hobbit', 'Esse é o seu melhor?','Rocco', '2017', '2009', 'J.R.R. Tolkien', 'Fantasia','Auto-Ajuda'),
('Estrelas além do Tempo','Psicologia Financeira', 'Seguinte', '2018', '2017', 'Margot Lee Shetterly', 'Biografia','Educação');

insert into Alunos (
Nome_Aluno,
Telefone,
Celular,
CPF,
RG,
Email_Aluno)
values
('Matteo Gabriel', '(13)9965-2103', '(12)98765-4102', '458.365.412-84', '32.345.675-9', 'matt@gmail.com'),
('Lucio Teodoro', '(14)9512-5411', '(11)98765-4102', '417.254.200-63', '57.220.980-7', 'lucieo@gmail.com'),
('Rael Gomes', '(12)9451-2036', '(11)98765-4102', '821.987.254-21', '92.211.678-2', 'raelgom@gmail.com'),
('Marceline Campos', '(11)9947-6521', '(11)98765-4102', '541.521.365-65', '24.223.528-4', 'marcelin@hotmail.com'),
('Julia Lima', '(15)9975-2134', '(12)98765-4102', '325.104.547-65', '18.823.776-7', 'juliaalim@hotmail.com');

insert into Professores (
Nome_Professor,
Endereço_Professor,
Telefone_Professor,
Celular_Professor,
CPF_Professor,
RG_Professor,
Email_Professor,
Titulação)
values
('Thiago Fagner', 'Rua dos Morangos Roxos, 123', '(11) 9876-6543', '(13) 99588-3652', '231.587.885-88', '32.125.456-32','thiafag@gmail.com','Mestre'),
('Bruna Vieira', 'Avenida Trinta de Abril, 192', '(11) 3422-5547', '(12) 95877-6548', '632.554.889-96', '25.417.452-87','brunavi@gmail.com','Doutor'),
('Alexandre Richard', 'Rua Rodrigo Faro, 239', '(13) 8894-3644', '(12) 35587-6543', '398.445.778-85', '57.745.766-48','richardale@hotmail.com','Doutor'),
('Joana Silverio', 'Avenida Pedras Finas, 21', '(12) 2247-8842', '(11) 69984-6997', '369.887.554-74', '11.458.214-45','joansil@hotmail.com','Mestre'),
('Caio Gomes', 'Avenida Freire, 784', '(11) 5547-3653', '(11) 99878-9774', '321.457.865-76', '22.523.478-85','caiogomes@hotmail.com','Mestre');

insert into Empréstimo (
Cod_Aluno,
Cod_Professor,
Cod_Livro,
Data_Empréstimo,
Data_Prevista,
Nome_Livro1,
Exemplar_Emprestado)
values
(2, '0', 1,'2018-02-10','2018-03-01','1','0'),
(3, '0', 3,'2019-03-12','2019-04-20','2','3'),
('0', 4, 4,'2018-05-13','2018-06-15','4','0'),
('0', 2, 5,'2020-09-03','2020-01-20','5','3'),
(1, '0', 2,'2020-06-01','2020-08-11','3','0');

insert into Devolução (
Cod_Aluno,
Cod_Professor,
Cod_Livro,
Situação_Empréstimo,
Quant_Livros_devolver)
values
(1, '0', 2,'completa','0'),
(2, '0', 1,'completa','0'),
(0, 4, 4,'completa','0'),
(0, 2, 5,'parcial','1'),
(3, '0', 3,'parcial','1');

select 
    Título_Livro,
    Autores
from
    Livros;
    
select
    Cod_Aluno
from
    Empréstimo;
    
update 
	Alunos
set
    Nome_Aluno = 'Marco de Paul Valente',
    Telefone = '(12) 9943-3244',
    Celular = '(11) 99543-9231',
    CPF = '410.541.569-41',
    RG = '54.412.447-52',
    Email_Aluno = 'marcodepaul@hotmail.com'
where
    Cod_Matrícula = 3;
	
delete from Professores where Cod_Professor = 2;

