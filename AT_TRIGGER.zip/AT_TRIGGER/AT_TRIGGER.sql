CREATE DATABASE EX_TRIGGER;
USE EX_TRIGGER;

CREATE TABLE Clientes (
    COD_Cliente INT AUTO_INCREMENT PRIMARY KEY,
    Nome_Cliente VARCHAR(40),
    Data_NascimentoC DATE,
    CPF_Cliente INT
);

CREATE TABLE Pedidos (
    COD_Pedido INT AUTO_INCREMENT PRIMARY KEY,
    COD_Cliente INT REFERENCES Clientes (COD_Cliente),
    Data_Pedido DATE,
    Nota_Fiscal INT,
    Valor_Total DECIMAL(10, 2 )
);

CREATE TABLE Produtos (
    COD_Produto INT AUTO_INCREMENT PRIMARY KEY,
    Desc_Produtos VARCHAR(40),
    Qtde_Produtos INT
);


CREATE TABLE ItemPedido (
    Item_Pedido INT AUTO_INCREMENT PRIMARY KEY,
    COD_Pedido INT REFERENCES Pedidos (COD_Pedido),
    Numero_Item INT,
    Valor_Unitario DECIMAL(10, 2 ),
    Qtde_IP INT,
    COD_Produto INT REFERENCES Produtos (COD_Produtos)
);

CREATE TABLE TAB_LOG (
    COD_Log INT AUTO_INCREMENT PRIMARY KEY,
    Data_Inicio DATETIME,
    Desc_Log VARCHAR(55)
);

-- 2 ---------------------------------------------------------------------------------------------------
INSERT INTO Clientes (
Nome_Cliente,
Data_NascimentoC,
CPF_Cliente)
VALUES
  ('Bruna Lima', '1990-01-01', 12345678901),
  ('Mateus Barreto', '1985-03-15', 23456789012),
  ('Kauan Henrique', '1998-07-22', 34567890123),
  ('Leonardo Souza', '1980-12-05', 45678901234),
  ('Paulo Mendez', '1995-04-30', 56789012345);

INSERT INTO Pedidos (
COD_Cliente, 
Data_Pedido, 
Nota_Fiscal, 
Valor_Total) 
VALUES
  (1, '2023-10-20', 1001, 150.00),
  (2, '2023-10-19', 1002, 200.50),
  (3, '2023-10-18', 1003, 75.25),
  (4, '2023-10-17', 1004, 300.75),
  (5, '2023-10-16', 1005, 50.20);
  
INSERT INTO Produtos (
Desc_Produtos, 
Qtde_Produtos)
VALUES
	('Smartphone Motorola', 80),
    ('Laptop Modelo Acer', 50),
    ('Fone de Ouvido Bluetooth', 75),
    ('Tablet Android', 200),
    ('Câmera Digital Profissional', 20);
    
INSERT INTO TAB_LOG (
Data_Inicio, 
Desc_Log)
VALUES
    ('2023-10-10 08:00:00', 'Produto com quantidade insuficiente'),
    ('2023-10-11 09:15:00', 'Produto com risco de quebrar'),
    ('2023-10-12 10:30:00', 'Produto não perecível'),
    ('2023-10-13 11:45:00', 'Produto inflamável'),
    ('2023-10-14 13:00:00', 'Produto quebrado');
-- 3 ---------------------------------------------------------------------------------------------------

DELIMITER $
CREATE TRIGGER TGR_Produto_Insert AFTER INSERT 
ON Pedidos
FOR EACH ROW
	BEGIN
    UPDATE Produtos 
    SET Qtde_Produtos = Qtde_Produtos - NEW. Qtde_Produtos
WHERE COD_Produto = NEW. COD_Produto;
END $
DELIMITER ;

-- 4 ---------------------------------------------------------------------------------------------------

DELIMITER $
CREATE TRIGGER TGR_ClientMod_Delete AFTER UPDATE
ON TAB_LOG
FOR EACH ROW
	BEGIN
    INSERT INTO TAB_LOG (Data_Inicio, Desc_Log)
    VALUES (NOW(), CONCAT('Cliente', OLD. Nome_Cliente, 'foi modificado'));

END $
    
    UPDATE TAB_LOG 
    SET Data_Inicio = 2023-09-20, Desc_Log = 'Modificações de Cliente: sem informações.',
	WHERE COD_Log = 2
END ;
DELIMITER ;

SHOW TRIGGERS;
-- 5 ---------------------------------------------------------------------------------------------------

DELIMITER $
CREATE TRIGGER Log_PedidosValorMaior AFTER INSERT
ON Pedidos
FOR EACH ROW
BEGIN
	IF  NEW. Valor_Total > 1000.00 THEN
		INSERT INTO TAB_LOG (Data_Inicio, Desc_Log)
        VALUES (NOW(), CONCAT ('Pedido', NEW. COD_Pedido, 'tem valor maior que R$1000'));
	END IF ;
END $
DELIMITER ;