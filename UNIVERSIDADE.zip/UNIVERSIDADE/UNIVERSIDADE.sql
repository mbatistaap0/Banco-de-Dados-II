create database Universidade;
use Universidade;

create table Alunos (
Cod_Matrícula int auto_increment primary key,
Nome_Aluno varchar (40),
Sobrenome_Aluno varchar (60),
Endereço_Aluno varchar (70),
Cidade_Aluno varchar (40),
Estado_Aluno varchar (2),
CEP_Aluno varchar (10),
RG_Aluno varchar (14),
CPF_Aluno varchar (15),
DataNascimento_Aluno datetime);

create table Disciplinas (
Cod_Disciplina int auto_increment primary key,
Nome_Disciplina varchar (40),
Carga_Horária_Disciplina time);

create table Professores (
Cod_Professor int auto_increment primary key,
Nome_Professor varchar (50),
Sobrenome_Professor varchar (40),
Endereço_Professor varchar (70),
Cidade_Professor varchar (50),
Estado_Professor varchar (2),
CEP_Professor varchar (9),
RG_Professor varchar (13),
CPF_Professor varchar (14),
DataNascimento_Professor datetime,
Formação_Professor varchar (20));

insert into Alunos (
Nome_Aluno,
Sobrenome_Aluno,
Endereço_Aluno,
Cidade_Aluno,
Estado_Aluno,
CEP_Aluno,
RG_Aluno,
CPF_Aluno,
DataNascimento_Aluno)
values
('Thayline','Garcia Paula','Lagoa Verde','Imperatriz','MA','68927-012','14.627.472-5','354.876.294-80','19990510'),
('Marisa','Torres Portela','Mossunguê','Curitiba','PR','11666-230','48.555.209-5','746.579.567-28','19880210'),
('Fernando','Zambelli Brito','Barra do Ceará','Fortaleza','CE','08774-130','24.597.667-5','463.638.645-00','20080218'),
('Ana Caroline','Debossam Rocha','Jardim Libanês','São Luís','MA','13031-230','24.986.381-2','715.164.457-40','20091203'),
('Clarice','Marques Regufe','Remedios','Santana','AP','17220-021','27.768.625-9','714.876.107-77','19971014');

insert into Disciplinas (
Nome_Disciplina,
Carga_Horária_Disciplina)
values
('Matemática','40:00:00'),
('Comunicação e Mídia','15:00:00'),
('Ciências Sociais','20:00:00'),
('Economia e Negócios','25:00:00'),
('Administração','20:00:00');

insert into Professores (
Nome_Professor,
Sobrenome_Professor,
Endereço_Professor,
Cidade_Professor,
Estado_Professor,
CEP_Professor,
RG_Professor,
CPF_Professor,
DataNascimento_Professor,
Formação_Professor)
values
('Robinson',' Silveira Campos','Rua Raimundo Correa','João Pessoa','PB','58052-560','18.825.626-9','280.152.954-08','1988-04-09','Pós-Graduação'),
('Martim','Barbosa Salles','Rua Itu','Recife','PE','52170-030','47.966.506-0','200.262.784-30','1999-05-01','Mestrado'),
('Joaquim','Silva Ramos','Rua Azul da Amplidão','São Luís','MA','65071-650','14.616.773-9','819.357.763-98','1960-05-20','Pós-Graduação'),
('Margot','Gabriela Fernandes','Avenida Perimetral da Silva','Teresina', 'PI','13321-764','13.322.221-7','854.214.559-64','1988-12-04','Doutorado'),
('Adrian','Lima Lopes','Rua Marcos da Costa','Gravataí','RS','94198-585','12.145.447-5','264.950.180-45','1990-08-04','Mestrado');

select
   Cod_Professor,
   Nome_Professor,
   Formação_Professor
from
   Professores;

/*-----------------------------------------------------------------------*/
select
   Nome_Disciplina,
   Carga_Horária_Disciplina
from
   Disciplinas
where
   Cod_Disciplina >= 2;

/*-----------------------------------------------------------------------*/
select * from Alunos
where
   Cod_Matrícula > 1 and DataNascimento_Aluno between '20010101' and '20100101';

/*-----------------------------------------------------------------------*/
select * from Alunos
where
   Cod_Matrícula > 2 and DataNascimento_Aluno > '20050101';
   
/*-----------------------------------------------------------------------*/   
alter table Professores add Carga_Horária_Prof time;
truncate table Professores;

/*-----------------------------------------------------------------------*/
insert into Professores (
Nome_Professor,
Sobrenome_Professor,
Endereço_Professor,
Cidade_Professor,
Estado_Professor,
CEP_Professor,
RG_Professor,
CPF_Professor,
DataNascimento_Professor,
Formação_Professor,
Carga_Horária_Prof)
values
('Robinson',' Silveira Campos','Rua Raimundo Correa','João Pessoa','PB','58052-560','18.825.626-9','280.152.954-08','1988-04-09','Pós-Graduação','20:00:00'),
('Martim','Barbosa Salles','Rua Itu','Recife','PE','52170-030','47.966.506-0','200.262.784-30','1999-05-01','Mestrado','40:00:00'),
('Joaquim','Silva Ramos','Rua Azul da Amplidão','São Luís','MA','65071-650','14.616.773-9','819.357.763-98','1960-05-20','Pós-Graduação','25:00:00'),
('Margot','Gabriela Fernandes','Avenida Perimetral da Silva','Teresina', 'PI','13321-764','13.322.221-7','854.214.559-64','1988-12-04','Doutorado','30:00:00'),
('Adrian','Lima Lopes','Rua Marcos da Costa','Gravataí','RS','94198-585','12.145.447-5','264.950.180-45','1990-08-04','Mestrado','15:00:00');

/*-----------------------------------------------------------------------*/
select
   Nome_Disciplina,
   Carga_Horária_Disciplina
from
   Disciplinas;
   
/*-----------------------------------------------------------------------*/
select
   Nome_Aluno,
   CPF_Aluno
from
   Alunos
where
   Nome_Aluno LIKE 'M&';
   
/*-----------------------------------------------------------------------*/
update
   Disciplinas
set
   Nome_Disciplina = 'Banco de Dados II'
where
   Cod_Disciplina = 2;
   
/*-----------------------------------------------------------------------*/   
select
   Cod_Professor,
   Formação_Professor
from
   Professores
where
   Nome_Professor and Formação_Professor
LIMIT 3;

/*-----------------------------------------------------------------------*/
select
   Cod_Professor,
   DataNascimento_Professor
from
   Professores
where
   Cod_Professor > 3 and DataNascimento_Professor > '20001110';
   
/*-----------------------------------------------------------------------*/
select
   Cod_Matrícula,
   DataNascimento_Aluno
from
   Alunos
where
   Cod_Matrícula > 3 and DataNascimento_Aluno = '20080312';

/*-----------------------------------------------------------------------*/
select
   Nome_Disciplina
from
   Disciplinas
order by
   Nome_Disciplina;

