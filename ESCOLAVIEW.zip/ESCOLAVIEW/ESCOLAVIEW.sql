CREATE DATABASE Escola;
USE Escola;

CREATE TABLE Alunos (
Aluno_ID int auto_increment primary key,
Nome_Aluno varchar (50),
Idade int);

CREATE TABLE Disciplinas (
Disciplina_ID int auto_increment primary key,
Nome_Disciplina varchar (40));

CREATE TABLE Notas (
Nota_ID int auto_increment primary key,
Aluno int references Alunos (Aluno_ID),
Disciplina int references Disciplinas (Disciplinas_ID),
Nota int);

-- 2 ----------------------------------------------------------------
INSERT INTO Alunos (
Nome_Aluno,
Idade)
VALUES
('Roberta Gomes', 16 ),
('Mateo Orochi', 17),
('Junior Carvalho', 15);

INSERT INTO Disciplinas (
Nome_Disciplina)
VALUES
('Matemática'),
('Biologia'),
('Inglês');

INSERT INTO Notas (
Aluno,
Disciplina,
Nota)
VALUES
( 2, 3, 10),
( 3, 3, 9),
( 1, 2, 9),
( 1, 3, 8),
( 2, 2, 7);

-- 3 ----------------------------------------------------------------
SELECT
	Nome_Disciplina,
	COUNT(Nome_Aluno) AS QtdAluno
FROM
	Disciplinas D
INNER JOIN Alunos A ON (A. Aluno_ID = D. Disciplina_ID)
GROUP BY
	Nome_Aluno;
    
-- 4 ----------------------------------------------------------------
SELECT
	SUM(Nota) as SomaNotas,
    Nome_Disciplina as Disciplina
FROM
	Notas N
INNER JOIN Disciplinas D ON (D. Disciplina_ID = N. Nota_ID)
ORDER BY
	Nota;
    
-- 5 ----------------------------------------------------------------
SELECT
	Nome_Aluno,
    MIN(Nota) as MenorNota
FROM
	Notas N 
INNER JOIN Alunos A ON (N.Nota_ID = A. Aluno_ID)
GROUP BY
	Nota;
    
-- 6 ----------------------------------------------------------------
SELECT
	Nome_Aluno,
    Idade
FROM
	Alunos
ORDER BY
	Idade;
    
-- 7 ----------------------------------------------------------------
SELECT
	MAX(Nota) as MaiorNota,
    Nome_Disciplina
FROM
	Notas N
INNER JOIN Disciplinas D ON (D. Disciplina_ID = N. Nota_ID)
GROUP BY
	Disciplina;
    
-- 8 ----------------------------------------------------------------
SELECT
	Nota,
    Nome_Aluno,
    Nome_Disciplina
FROM
	Notas N
INNER JOIN Alunos A ON (A. Aluno_ID = N. Nota_ID)
INNER JOIN Disciplinas D ON (D. Disciplina_ID = N. Nota_ID)
GROUP BY
	Nome_Disciplina
ORDER BY
	Nome_Aluno,
    Nome_Disciplina;

-- ----------------------------------------------------------------
-- ----------------------------------------------------------------
-- ----------------------------------------------------------------

-- 9 - Crie uma VIEW para a média de notas por aluno e disciplina(2 inner join e AVG)
-- 10 - Crie uma VIEW para detalhes de alunos com melhor nota por disciplina(2 inner join e MAX)
-- 11 - Crie uma VIEW para detalhes de alunos com pior nota por disciplina(2 inner join e MIN)

-- 9
CREATE VIEW vwMediaNota
	AS
		SELECT
			Nome_Aluno as Aluno,
			Nome_Disciplina as Disciplina,
            AVG (Nota) as MediaNota
FROM
	Notas N 
INNER JOIN Alunos A ON (N. Nota_ID = A. Aluno_ID)
INNER JOIN Disciplinas D ON (N. Nota_ID = D. Disciplina_ID)
GROUP BY Nome_Aluno, Nome_Disciplina;

SELECT * FROM vwMediaNota; 

-- 10 
CREATE VIEW vwDetalheAlunoM
	AS
		SELECT
			MAX(Nota) as MelhorNota,
            Nome_Aluno,
            Nome_Disciplina
FROM
	Notas N
INNER JOIN Alunos A ON (N. Nota_ID = A. Aluno_ID)
INNER JOIN Disciplinas D ON (N. Nota_ID = D. Disciplina_ID)
GROUP BY Nome_Aluno, Nome_Disciplina;
	
SELECT * FROM vwDetalheAlunoM; 
    
-- 11
CREATE VIEW vwDetalheAlunoP
	AS
		SELECT
			MIN(Nota) as PiorNota,
            A. Nome_Aluno,
            D. Nome_Disciplina
FROM
	Notas N
INNER JOIN Alunos A ON (N. Nota_ID = A. Aluno_ID)
INNER JOIN Disciplinas D ON (N. Nota_ID = D. Disciplina_ID)
GROUP BY Nome_Aluno, Nome_Disciplina;

SELECT * FROM vwDetalheAlunoP;

